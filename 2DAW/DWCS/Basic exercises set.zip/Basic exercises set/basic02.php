<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $base = 4; 
    $height = 5;

    echo "<h1> Area: </h1>";
    echo "<p>". ($base * $height)/2 ."</p>";
    ?>
</body>
</html>