<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $_1 = rand(1,49);
    $_2 = rand(1,49);
    $_3 = rand(1,49);
    $_4 = rand(1,49);
    $_5 = rand(1,49);
    $_6 = rand(1,49);

    echo "Bonoloto Combination: " . $_1 .",". $_2 .",". $_3 .",". $_4 .",". $_5 .",". $_6 
    ?>
</body>
</html>